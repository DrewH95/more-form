import UserForm from './components/UserForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <UserForm/>
    </div>
  );
}

export default App;
